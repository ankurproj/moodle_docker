<?php
$string['pluginname'] = 'Application Check';
