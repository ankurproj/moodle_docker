<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'tool_applicationcheck';
$plugin->version   = 2025060900;       
$plugin->requires  = 2024042200;       
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = '0.1';
