<?php
defined("MOODLE_INTERNAL") || die();

$plugin->component = "local_profile_feedback_mapper";
$plugin->version = 2026021100;
$plugin->requires = 2022041900; // Moodle 4.x
