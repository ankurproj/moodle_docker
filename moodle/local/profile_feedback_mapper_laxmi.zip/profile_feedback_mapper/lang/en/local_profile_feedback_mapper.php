<?php
$string["pluginname"] = "Profile Feedback Mapper";
$string["opsview"] = "Profile Feedback Sync – Ops";
$string["settings"] = "Profile Feedback Mapper Settings";
$string["logretentiondays"] = "Log retention (days)";
$string["logretentiondays_desc"] = "Number of days to keep sync and run logs";
