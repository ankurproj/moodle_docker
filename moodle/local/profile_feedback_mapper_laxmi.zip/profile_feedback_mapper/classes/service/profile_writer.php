<?php
namespace local_profile_feedback_mapper\service;

defined("MOODLE_INTERNAL") || die();

class profile_writer
{
    public function write(int $userid, string $shortname, string $value): void
    {
        global $DB;

        $field = $DB->get_record(
            "user_info_field",
            ["shortname" => $shortname],
            "*",
            IGNORE_MISSING,
        );
        if (!$field) {
            throw new \moodle_exception("Profile field not found");
        }

        $existing = $DB->get_record("user_info_data", [
            "userid" => $userid,
            "fieldid" => $field->id,
        ]);

        if ($existing) {
            if ($existing->data === $value) {
                return;
            }
            $existing->data = $value;
            $DB->update_record("user_info_data", $existing);
        } else {
            $DB->insert_record(
                "user_info_data",
                (object) [
                    "userid" => $userid,
                    "fieldid" => $field->id,
                    "data" => $value,
                    "dataformat" => 0,
                ],
            );
        }
    }
}
