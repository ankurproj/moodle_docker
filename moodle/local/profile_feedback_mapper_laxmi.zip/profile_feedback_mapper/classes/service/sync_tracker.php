<?php
namespace local_profile_feedback_mapper\service;

defined("MOODLE_INTERNAL") || die();

class sync_tracker
{
    /**
     * Last processed feedback id for a mapping
     */
    public function get_last_feedbackid(int $mappingid): int
    {
        global $DB;

        return (int) $DB->get_field_sql(
            "
            SELECT MAX(feedbackid)
            FROM {local_pf_sync}
            WHERE mappingid = :mappingid
        ",
            ["mappingid" => $mappingid],
        ) ?:
            0;
    }

    /**
     * Check if value unchanged for user
     */
    public function unchanged(int $mappingid, int $userid, string $hash): bool
    {
        global $DB;

        $rec = $DB->get_record("local_pf_sync", [
            "mappingid" => $mappingid,
            "userid" => $userid,
        ]);

        return $rec && $rec->valuehash === $hash;
    }

    /**
     * Record successful sync
     */
    public function record_success(
        int $mappingid,
        int $userid,
        int $feedbackid,
        string $hash,
    ): void {
        global $DB;

        $rec = $DB->get_record("local_pf_sync", [
            "mappingid" => $mappingid,
            "userid" => $userid,
        ]);

        $data = (object) [
            "mappingid" => $mappingid,
            "userid" => $userid,
            "feedbackid" => $feedbackid,
            "valuehash" => $hash,
            "lastsynced" => time(),
            "status" => "success",
        ];

        if ($rec) {
            $data->id = $rec->id;
            $DB->update_record("local_pf_sync", $data);
        } else {
            $DB->insert_record("local_pf_sync", $data);
        }
    }
}
