<?php
namespace local_profile_feedback_mapper\service;

defined("MOODLE_INTERNAL") || die();

/**
 * Repository for mapping configuration
 *
 * Central place for all mapping-related DB access.
 * Keeps cron & UI logic clean and testable.
 */
class mapping_repository
{
    /**
     * Get all enabled mappings
     *
     * @return \stdClass[] indexed by id
     */
    public function get_enabled_mappings(): array
    {
        global $DB;

        return $DB->get_records("local_pf_map", ["enabled" => 1]);
    }

    /**
     * Get a single mapping by id
     *
     * @param int $id
     * @return \stdClass|null
     */
    public function get_mapping(int $id): ?\stdClass
    {
        global $DB;

        return $DB->get_record(
            "local_pf_map",
            ["id" => $id],
            "*",
            IGNORE_MISSING,
        );
    }

    /**
     * Delete a mapping and its sync state
     *
     * @param int $id
     * @return void
     */
    public function delete_mapping(int $id): void
    {
        global $DB;

        // Delete runtime sync state first
        $DB->delete_records("local_pf_sync", ["mappingid" => $id]);

        // Delete mapping
        $DB->delete_records("local_pf_map", ["id" => $id]);
    }

    /**
     * Check if a mapping already exists
     *
     * Prevents duplicate (assignment + criterion + profile field)
     *
     * @param int $assignmentid
     * @param int $criterionindex
     * @param string $profilefield
     * @param int $excludeid
     * @return bool
     */
    public function mapping_exists(
        int $assignmentid,
        int $criterionindex,
        string $profilefield,
        int $excludeid = 0,
    ): bool {
        global $DB;

        $sql = "
            SELECT 1
              FROM {local_pf_map}
             WHERE assignmentid = :assignmentid
               AND criterion_index = :criterion
               AND profile_field = :profile
               AND id <> :excludeid
        ";

        return $DB->record_exists_sql($sql, [
            "assignmentid" => $assignmentid,
            "criterion" => $criterionindex,
            "profile" => $profilefield,
            "excludeid" => $excludeid,
        ]);
    }

    /**
     * Save (insert or update) a mapping
     *
     * @param \stdClass $data
     * @return int mapping id
     */
    public function save_mapping(\stdClass $data): int
    {
        global $DB;

        $now = time();
        $data->timemodified = $now;

        if (!empty($data->id)) {
            $DB->update_record("local_pf_map", $data);
            return $data->id;
        }

        $data->timecreated = $now;
        return $DB->insert_record("local_pf_map", $data);
    }

    /**
     * Get mappings for a specific assignment
     *
     * Useful for assignment-level reports later
     *
     * @param int $assignmentid
     * @return \stdClass[]
     */
    public function get_mappings_by_assignment(int $assignmentid): array
    {
        global $DB;

        return $DB->get_records("local_pf_map", [
            "assignmentid" => $assignmentid,
            "enabled" => 1,
        ]);
    }

    /**
     * Get mappings that target a given profile field
     *
     * Used by priority resolver
     *
     * @param string $profilefield
     * @return \stdClass[]
     */
    public function get_mappings_by_profile_field(string $profilefield): array
    {
        global $DB;

        return $DB->get_records("local_pf_map", [
            "profile_field" => $profilefield,
            "enabled" => 1,
        ]);
    }
}
