<?php
namespace local_profile_feedback_mapper\service;

defined("MOODLE_INTERNAL") || die();

class priority_resolver
{
    /**
     * Decide whether this mapping can overwrite the profile field
     */
    public function can_write(
        int $userid,
        string $profilefield,
        int $newpriority,
    ): bool {
        global $DB;

        // Find existing successful syncs for same profile field
        $sql = "
            SELECT m.priority
            FROM {local_pf_sync} s
            JOIN {local_pf_map} m ON m.id = s.mappingid
            WHERE s.userid = :userid
              AND m.profile_field = :profilefield
              AND s.status = 'success'
            ORDER BY m.priority DESC
            LIMIT 1
        ";

        $existing = $DB->get_record_sql($sql, [
            "userid" => $userid,
            "profilefield" => $profilefield,
        ]);

        if (!$existing) {
            return true; // nothing written yet
        }

        // Allow overwrite only if higher priority
        return $newpriority > $existing->priority;
    }
}
