<?php
namespace local_profile_feedback_mapper\service;

defined("MOODLE_INTERNAL") || die();

class feedback_reader
{
    /**
     * Fetch NEW structured feedback rows since last processed ID
     */
    public function get_new_feedback(
        int $assignmentid,
        int $criterionindex,
        int $afterid,
    ): array {
        global $DB;

        return $DB->get_records_sql(
            "
            SELECT
                afs.id            AS feedbackid,
                afs.grade         AS gradeid,
                g.userid,
                afs.commenttext
            FROM {assignfeedback_structured} afs
            JOIN {assign_grades} g ON g.id = afs.grade
            WHERE afs.assignment = :assignmentid
              AND afs.criterion  = :criterion
              AND afs.id > :afterid
            ORDER BY afs.id ASC
        ",
            [
                "assignmentid" => $assignmentid,
                "criterion" => $criterionindex,
                "afterid" => $afterid,
            ],
        );
    }

    /**
     * Max feedback id for a mapping (cheap check)
     */
    public function get_max_feedbackid(
        int $assignmentid,
        int $criterionindex,
    ): int {
        global $DB;

        return (int) $DB->get_field_sql(
            "
            SELECT MAX(id)
            FROM {assignfeedback_structured}
            WHERE assignment = :assignmentid
              AND criterion  = :criterion
        ",
            [
                "assignmentid" => $assignmentid,
                "criterion" => $criterionindex,
            ],
        ) ?:
            0;
    }
}
