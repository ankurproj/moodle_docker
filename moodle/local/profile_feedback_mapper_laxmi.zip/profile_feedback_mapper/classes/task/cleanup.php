<?php
namespace local_profile_feedback_mapper\task;

use core\task\scheduled_task;

defined("MOODLE_INTERNAL") || die();

class cleanup extends scheduled_task
{
    public function get_name()
    {
        return "Profile feedback mapper cleanup";
    }

    public function execute()
    {
        global $DB;

        $days = (int) get_config(
            "local_profile_feedback_mapper",
            "logretentiondays",
        );

        if ($days <= 0) {
            return;
        }

        $cutoff = time() - $days * DAYSECS;

        // Cleanup run logs
        $DB->delete_records_select("local_pf_run_log", "startedat < ?", [
            $cutoff,
        ]);

        // Cleanup sync logs
        $DB->delete_records_select("local_pf_sync", "lastsynced < ?", [
            $cutoff,
        ]);
    }
}
