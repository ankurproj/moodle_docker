<?php
namespace local_profile_feedback_mapper\task;

use core\task\scheduled_task;

defined("MOODLE_INTERNAL") || die();

class sync extends scheduled_task
{
    public function get_name(): string
    {
        return "Profile feedback sync";
    }

    public function execute()
    {
        global $DB;

        // ---- Start run log (minimal, optional) ----
        $runid = $DB->insert_record(
            "local_pf_run_log",
            (object) [
                "startedat" => time(),
                "status" => "running",
            ],
        );

        try {
            // 1. Get enabled mappings
            $mappings = $DB->get_records("local_pf_map", ["enabled" => 1]);

            foreach ($mappings as $map) {
                // 2. Read mapping-level cursor
                $lastid = (int) ($map->last_feedback_id ?? 0);

                // 3. Fetch ONLY new structured feedback rows
                $rows = $DB->get_records_sql(
                    "
                    SELECT
                        afs.id,
                        afs.commenttext,
                        g.userid
                    FROM {assignfeedback_structured} afs
                    JOIN {assign_grades} g ON g.id = afs.grade
                    WHERE g.assignment = :assignmentid
                      AND afs.criterion  = :criterion
                      AND afs.id > :lastid
                    ORDER BY afs.id ASC
                ",
                    [
                        "assignmentid" => $map->assignmentid,
                        "criterion" => $map->criterion_index,
                        "lastid" => $lastid,
                    ],
                );

                if (!$rows) {
                    continue; // NOTHING changed → cheap exit
                }

                $maxid = $lastid;

                foreach ($rows as $row) {
                    $value = trim(strip_tags($row->commenttext));
                    $hash = sha1($value);

                    // 4. Skip if same value already synced
                    $existing = $DB->get_record("local_pf_sync", [
                        "mappingid" => $map->id,
                        "userid" => $row->userid,
                    ]);

                    if ($existing && $existing->valuehash === $hash) {
                        continue;
                    }

                    // 5. Write profile field
                    $field = $DB->get_record(
                        "user_info_field",
                        [
                            "shortname" => $map->profile_field,
                        ],
                        "*",
                        IGNORE_MISSING,
                    );

                    if ($field) {
                        $data = $DB->get_record("user_info_data", [
                            "userid" => $row->userid,
                            "fieldid" => $field->id,
                        ]);

                        if ($data) {
                            $data->data = $value;
                            $DB->update_record("user_info_data", $data);
                        } else {
                            $DB->insert_record(
                                "user_info_data",
                                (object) [
                                    "userid" => $row->userid,
                                    "fieldid" => $field->id,
                                    "data" => $value,
                                    "dataformat" => 0,
                                ],
                            );
                        }
                    }

                    // 6. Audit log (per user, optional but useful)
                    $DB->insert_record(
                        "local_pf_sync",
                        (object) [
                            "mappingid" => $map->id,
                            "userid" => $row->userid,
                            "feedbackid" => $row->id,
                            "valuehash" => $hash,
                            "lastsynced" => time(),
                            "status" => "success",
                        ],
                    );

                    $maxid = max($maxid, $row->id);
                }

                // 7. Advance cursor (THIS is the magic)
                if ($maxid > $lastid) {
                    $map->last_feedback_id = $maxid;
                    $DB->update_record("local_pf_map", $map);
                }
            }

            $DB->update_record(
                "local_pf_run_log",
                (object) [
                    "id" => $runid,
                    "endedat" => time(),
                    "status" => "success",
                ],
            );
        } catch (\Throwable $e) {
            $DB->update_record(
                "local_pf_run_log",
                (object) [
                    "id" => $runid,
                    "endedat" => time(),
                    "status" => "failed",
                    "errormsg" => $e->getMessage(),
                ],
            );
        }
    }
}
