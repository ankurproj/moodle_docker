<?php
defined("MOODLE_INTERNAL") || die();

$tasks = [
    [
        "classname" => 'local_profile_feedback_mapper\task\sync',
        "blocking" => 0,
        "minute" => "*/5",
        "hour" => "*",
        "day" => "*",
        "month" => "*",
        "dayofweek" => "*",
    ],
];
