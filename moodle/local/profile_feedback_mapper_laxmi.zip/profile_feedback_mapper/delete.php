<?php
require_once __DIR__ . "/../../config.php";
require_once $CFG->libdir . "/adminlib.php";

require_login();
require_capability("moodle/site:config", context_system::instance());

admin_externalpage_setup("local_profile_feedback_mapper");

$id = required_param("id", PARAM_INT);
$confirm = optional_param("confirm", 0, PARAM_BOOL);

$mapping = $DB->get_record("local_pf_map", ["id" => $id], "*", MUST_EXIST);

if ($confirm && confirm_sesskey()) {
    // Cleanup runtime sync state
    $DB->delete_records("local_pf_sync", ["mappingid" => $id]);

    // Delete mapping
    $DB->delete_records("local_pf_map", ["id" => $id]);

    redirect(
        new moodle_url("/local/profile_feedback_mapper/index.php"),
        "Mapping deleted successfully",
        null,
        \core\output\notification::NOTIFY_SUCCESS,
    );
}

$PAGE->set_url("/local/profile_feedback_mapper/delete.php", ["id" => $id]);
$PAGE->set_title("Delete Mapping");
$PAGE->set_heading("Delete Mapping");

echo $OUTPUT->header();

echo $OUTPUT->confirm(
    "Are you sure you want to delete this mapping?<br><br><strong>This action cannot be undone.</strong>",
    new moodle_url("/local/profile_feedback_mapper/delete.php", [
        "id" => $id,
        "confirm" => 1,
        "sesskey" => sesskey(),
    ]),
    new moodle_url("/local/profile_feedback_mapper/index.php"),
);

echo $OUTPUT->footer();
