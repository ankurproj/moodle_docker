<?php
require_once __DIR__ . "/../../config.php";
require_once $CFG->libdir . "/adminlib.php";

/**
 * IMPORTANT:
 * Explicit include avoids blank page / redirect issue
 * (Moodle autoload is unreliable for local plugins during dev)
 */
require_once __DIR__ . "/classes/service/mapping_repository.php";

use local_profile_feedback_mapper\service\mapping_repository;

require_login();
require_capability("moodle/site:config", context_system::instance());

admin_externalpage_setup("local_profile_feedback_mapper");

$PAGE->set_title("Profile Feedback Mapper");
$PAGE->set_heading("Profile Feedback Mapper");

global $DB, $OUTPUT;

/* ============================================================
 * PARAMS (ALL OPTIONAL – NEVER use required_param here)
 * ============================================================ */
$courseid = optional_param("courseid", 0, PARAM_INT);
$assignmentid = optional_param("assignmentid", 0, PARAM_INT);
$criteriaraw = optional_param("criterion_raw", "", PARAM_TEXT);
$profilefield = optional_param("profile_field", "", PARAM_TEXT);

$save = optional_param("save", 0, PARAM_BOOL);
$editid = optional_param("edit", 0, PARAM_INT);
$deleteid = optional_param("delete", 0, PARAM_INT);

/* ============================================================
 * REPOSITORY
 * ============================================================ */
$repo = new mapping_repository();

/* ============================================================
 * DELETE
 * ============================================================ */
if ($deleteid && confirm_sesskey()) {
    $repo->delete_mapping($deleteid);
    redirect(
        new moodle_url("/local/profile_feedback_mapper/index.php"),
        "Mapping deleted successfully",
        null,
        \core\output\notification::NOTIFY_SUCCESS,
    );
}

/* ============================================================
 * LOAD EDIT RECORD
 * ============================================================ */
$editing = null;
if ($editid) {
    $editing = $repo->get_mapping($editid);
    if ($editing) {
        $courseid = $editing->courseid;
        $assignmentid = $editing->assignmentid;
        $criteriaraw =
            $editing->criteriasetid . ":" . $editing->criterion_index;
        $profilefield = $editing->profile_field;
    }
}

/* ============================================================
 * SAVE (FINAL SUBMIT ONLY)
 * ============================================================ */
if ($save && confirm_sesskey()) {
    if (
        $courseid <= 0 ||
        $assignmentid <= 0 ||
        empty($criteriaraw) ||
        empty($profilefield)
    ) {
        echo $OUTPUT->notification(
            "Please select Course, Assignment, Criterion, and Profile field before saving.",
            \core\output\notification::NOTIFY_ERROR,
        );
    } else {
        [$criteriasetid, $criterionindex] = explode(":", $criteriaraw);

        // Resolve criterion name
        $criterionname = "";
        $cs = $DB->get_record(
            "assignfeedback_structured_cs",
            ["id" => $criteriasetid],
            "id,criteria",
        );
        if ($cs && $cs->criteria) {
            $decoded = json_decode($cs->criteria, true);
            if (isset($decoded[$criterionindex]["name"])) {
                $criterionname = $decoded[$criterionindex]["name"];
            }
        }

        if (empty($criterionname)) {
            echo $OUTPUT->notification(
                "Invalid structured feedback criterion selected.",
                \core\output\notification::NOTIFY_ERROR,
            );
        } else {
            $record = (object) [
                "id" => optional_param("id", 0, PARAM_INT),
                "courseid" => $courseid,
                "assignmentid" => $assignmentid,
                "criteriasetid" => (int) $criteriasetid,
                "criterion_index" => (int) $criterionindex,
                "criterion_name" => $criterionname,
                "profile_field" => $profilefield,
                "enabled" => 1,
            ];

            if (
                $repo->mapping_exists(
                    $record->assignmentid,
                    $record->criterion_index,
                    $record->profile_field,
                    $record->id,
                )
            ) {
                echo $OUTPUT->notification(
                    "This mapping already exists.",
                    \core\output\notification::NOTIFY_ERROR,
                );
            } else {
                $repo->save_mapping($record);
                redirect(
                    new moodle_url("/local/profile_feedback_mapper/index.php"),
                    "Mapping saved successfully",
                    null,
                    \core\output\notification::NOTIFY_SUCCESS,
                );
            }
        }
    }
}

/* ============================================================
 * DATA SOURCES
 * ============================================================ */

// Courses
$courses = $DB->get_records_menu(
    "course",
    ["visible" => 1],
    "fullname",
    "id, fullname",
);
unset($courses[1]); // remove site course

// Assignments
$assignments = $courseid
    ? $DB->get_records_menu(
        "assign",
        ["course" => $courseid],
        "name",
        "id, name",
    )
    : [];

// Structured feedback criteria
$criteria = [];
$criteriasets = $DB->get_records("assignfeedback_structured_cs");
foreach ($criteriasets as $cs) {
    if (!$cs->criteria) {
        continue;
    }
    $decoded = json_decode($cs->criteria, true);
    if (!is_array($decoded)) {
        continue;
    }
    foreach ($decoded as $idx => $c) {
        if (!empty($c["name"])) {
            $criteria[$cs->id . ":" . $idx] = $cs->name . " → " . $c["name"];
        }
    }
}

// Profile fields
$profilefields = $DB->get_records_menu(
    "user_info_field",
    null,
    "name",
    "shortname, name",
);

/* ============================================================
 * OUTPUT
 * ============================================================ */

echo $OUTPUT->header();
echo html_writer::tag("h3", $editing ? "Edit Mapping" : "Add Mapping");

echo html_writer::start_tag("form", ["method" => "post"]);
echo html_writer::input_hidden_params($PAGE->url);

echo html_writer::empty_tag("input", [
    "type" => "hidden",
    "name" => "sesskey",
    "value" => sesskey(),
]);

if ($editing) {
    echo html_writer::empty_tag("input", [
        "type" => "hidden",
        "name" => "id",
        "value" => $editing->id,
    ]);
}

/* Course */
echo html_writer::tag("label", "Course");
echo html_writer::select(
    $courses,
    "courseid",
    $courseid,
    ["" => "Select course"],
    ["onchange" => "this.form.submit()"],
);
echo "<br><br>";

/* Assignment */
if ($courseid) {
    echo html_writer::tag("label", "Assignment");
    echo html_writer::select(
        $assignments,
        "assignmentid",
        $assignmentid,
        ["" => "Select assignment"],
        ["onchange" => "this.form.submit()"],
    );
    echo "<br><br>";
}

/* Criterion + profile field */
if ($assignmentid) {
    echo html_writer::tag("label", "Structured Feedback Criterion");
    echo html_writer::select($criteria, "criterion_raw", $criteriaraw, [
        "" => "Select criterion",
    ]);
    echo "<br><br>";

    echo html_writer::tag("label", "Profile Field");
    echo html_writer::select($profilefields, "profile_field", $profilefield, [
        "" => "Select profile field",
    ]);
    echo "<br><br>";

    echo html_writer::empty_tag("input", [
        "type" => "submit",
        "name" => "save",
        "value" => $editing ? "Update Mapping" : "Save Mapping",
    ]);
}

echo html_writer::end_tag("form");

/* ============================================================
 * EXISTING MAPPINGS
 * ============================================================ */

echo html_writer::tag("h3", "Existing Mappings");

$mappings = $DB->get_records("local_pf_map");

if (!$mappings) {
    echo $OUTPUT->notification("No mappings configured yet.", "info");
} else {
    $coursenames = $DB->get_records_menu("course", null, "", "id, fullname");
    $assignnames = $DB->get_records_menu("assign", null, "", "id, name");

    $table = new html_table();
    $table->head = [
        "Course",
        "Assignment",
        "Criterion",
        "Profile Field",
        "Actions",
    ];

    foreach ($mappings as $m) {
        $table->data[] = [
            format_string($coursenames[$m->courseid] ?? "-"),
            format_string($assignnames[$m->assignmentid] ?? "-"),
            s($m->criterion_name),
            s($m->profile_field),
            html_writer::link(
                new moodle_url($PAGE->url, ["edit" => $m->id]),
                "Edit",
            ) .
            " | " .
            html_writer::link(
                new moodle_url($PAGE->url, [
                    "delete" => $m->id,
                    "sesskey" => sesskey(),
                ]),
                "Delete",
                ["onclick" => "return confirm('Are you sure?');"],
            ),
        ];
    }

    echo html_writer::table($table);
}

echo $OUTPUT->footer();
