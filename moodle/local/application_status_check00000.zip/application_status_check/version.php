<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_application_status_check';
$plugin->version   = 2026012200; // YYYYMMDDXX.
$plugin->requires  = 2019052000; // Moodle 3.7+ minimal; adjust as needed.
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = '0.1';


