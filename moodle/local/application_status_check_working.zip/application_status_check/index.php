<?php
require_once(__DIR__ . '/../../config.php');

global $DB, $PAGE, $OUTPUT, $CFG;

$context = context_system::instance();
$PAGE->set_url(new moodle_url('/local/application_status_check/index.php'));
$PAGE->set_context($context);
$PAGE->set_title(get_string('pluginname', 'local_application_status_check'));
$PAGE->set_heading(get_string('checkstatus', 'local_application_status_check'));

require_once($CFG->dirroot . '/local/application_status_check/classes/form/status_form.php');
require_once($CFG->libdir . '/gradelib.php');

$PAGE->requires->css(new moodle_url('/local/application_status_check/styles.css'));

echo $OUTPUT->header();

$form = new \local_application_status_check\form\status_form();

// Show a simple landing page with a single button unless the form is explicitly opened.
$open = optional_param('open', 0, PARAM_INT);
if ($open == 0 && $_SERVER['REQUEST_METHOD'] === 'GET') {
    echo $OUTPUT->heading(get_string('pluginname', 'local_application_status_check'));
    echo html_writer::tag('p', get_string('landinginfo', 'local_application_status_check'));
    $url = new moodle_url('/local/application_status_check/index.php', ['open' => 1]);
    echo html_writer::link($url, get_string('checkstatus', 'local_application_status_check'), ['class' => 'btn btn-primary btn-lg']);
    echo $OUTPUT->footer();
    exit;
}

if ($form->is_cancelled()) {
    redirect(new moodle_url('/'));
} else if ($data = $form->get_data()) {
    $email = trim(core_text::strtolower($data->email ?? ''));
        $dobts = (int)($data->dob ?? 0);
        $schemename = trim($data->course ?? '');
        $courseid = isset($data->courseid) ? (int)$data->courseid : 0;

        // 1) Find user by email.
        $user = $DB->get_record('user', ['email' => $email, 'deleted' => 0], '*', IGNORE_MISSING);
        if (!$user) {
            echo $OUTPUT->notification(get_string('usernotfound', 'local_application_status_check'), 'notifyproblem');
            $form->display();
            echo $OUTPUT->footer();
            exit;
        }

        // TEST MODE: skip DOB validation for testing. Use email only to find schemes/courses.
        $dobvalid = true;

        // 3) If no course selected yet, handle the 'Find course' action by auto-detecting
        // the applied/enrolled course for the user. The form initially shows only a
        // 'Find course' button; when clicked we detect a single course and re-display
        // the form showing that course and a 'Check status' button.
        if ($courseid === 0) {
            require_once($CFG->dirroot . '/course/lib.php');
            // If the user clicked the 'Find course' button, auto-detect.
            if (!empty($data->getscheme)) {
                $enrolled = enrol_get_users_courses($user->id, true, 'id,fullname,shortname');
                if (empty($enrolled)) {
                    echo $OUTPUT->notification(get_string('notenrolledany', 'local_application_status_check'), 'notifyproblem');
                    $form->display();
                    echo $OUTPUT->footer();
                    exit;
                }

                // If multiple courses, pick the most recently created (highest id) as a heuristic.
                $chosen = null;
                foreach ($enrolled as $c) {
                    if ($chosen === null || $c->id > $chosen->id) {
                        $chosen = $c;
                    }
                }

                $label = trim(($chosen->shortname ? $chosen->shortname . ' - ' : '') . $chosen->fullname);
                $form = new \local_application_status_check\form\status_form(null, ['detectedcourse' => ['id' => $chosen->id, 'label' => $label]]);
                $form->set_data(['email' => $email, 'dob' => $dobts]);
                echo $OUTPUT->notification(get_string('schemenotice', 'local_application_status_check'), 'notifymessage');
                $form->display();
                echo $OUTPUT->footer();
                exit;
            }

            // No findcourse action: just re-display the initial form (shouldn't normally happen).
            $form->display();
            echo $OUTPUT->footer();
            exit;
        }

        // 4) Display application status using gradebook 'Status Evaluation' scale.
        $course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);

        echo html_writer::tag('h3', get_string('statusresult', 'local_application_status_check'));
        $items = [];
        $items[] = format_string(get_string('email', 'local_application_status_check') . ': ' . s($email));
        $items[] = format_string(get_string('dob', 'local_application_status_check') . ': ' . userdate($dobts));
        $items[] = format_string(get_string('course', 'local_application_status_check') . ': ' . format_string($course->shortname ?: $course->fullname));

        // Find the grade_item for 'Status Evaluation' within this course.
        $gi = $DB->get_record_sql(
            "SELECT gi.id, gi.scaleid FROM {grade_items} gi WHERE gi.itemname = :itemname AND gi.itemtype = 'mod' AND gi.itemmodule = 'assign' AND gi.courseid = :courseid",
            ['itemname' => 'Status Evaluation', 'courseid' => $course->id]
        );

        if (!$gi) {
            $items[] = format_string(get_string('nostatusevaluation', 'local_application_status_check') . '');
            echo html_writer::alist($items);
            echo $OUTPUT->footer();
            exit;
        }

        // Get the user's grade record for that grade_item.
        $gg = $DB->get_record('grade_grades', ['itemid' => $gi->id, 'userid' => $user->id], '*', IGNORE_MISSING);
        if (!$gg || $gg->finalgrade === null || $gg->finalgrade === '') {
            $items[] = format_string(get_string('nostatusfound', 'local_application_status_check'));
            echo html_writer::alist($items);
            echo $OUTPUT->footer();
            exit;
        }

        // Map numeric finalgrade -> status text using scale.
        $scale = $DB->get_record('scale', ['id' => $gi->scaleid], '*', MUST_EXIST);
        $scaleitems = array_map('trim', explode(',', $scale->scale));
        $final = (int)$gg->finalgrade;
        $status = isset($scaleitems[$final - 1]) ? $scaleitems[$final - 1] : get_string('unknown', 'local_application_status_check');

        $items[] = format_string(get_string('gradestatus', 'local_application_status_check') . ': ' . s($status));
        echo html_writer::alist($items);
        echo $OUTPUT->footer();
        exit;
    } else {
        $form->display();
        echo $OUTPUT->footer();
    }